/*
 *  Copyright (C) 1998-99 Luca Deri <deri@unipi.it>
 *                      
 *			  Centro SERRA, University of Pisa
 *			  http://www-serra.unipi.it/
 *  					
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "ntop.h"

/* Extern */
extern int newSock, refreshRate;
#ifndef WIN32
extern FlowFilterList *flowsList;
#endif
extern char *device;
#ifdef HAVE_CURSES
extern RETSIGTYPE cleanup(int signo);
#endif
extern void printAllSessionsHTML(char* host);
extern void printMulticastStats(int, int);
extern void printHostsTraffic(int, int, int, int);
extern void printIpAccounting(int, int, int);
extern void printHostsInfo(int, int);
extern void printActiveTCPSessions();
extern void printIpProtocolDistribution(int mode, int);
extern void printIpTrafficMatrix();
extern void printIpProtocolUsage();
extern void printThptStats(int);
extern void printDomainStats(int, int);
#ifndef WIN32
extern void listNetFlows();
#endif
extern void printProtoTraffic();
extern void printLsofData(int mode);
#ifdef HAVE_LSOF
extern void printProcessInfo(int processPid);
#endif
#ifdef MULTITHREADED
extern pthread_mutex_t hostsHashMutex; 
#endif
extern time_t actTime;

/* Global */
static char requestedURL[128], pw[64];

char *dirs[] = { 
  ".",                   /* Local   */
  "/etc/ntop",           /* Default */
  "/opt/ntop/etc/ntop",  /* Solaris */
  "/usr/local/etc/ntop", /* BSD     */
  NULL };
 

/* Courtesy of Hans Werner Strube <strube@physik3.gwdg.de> */
static u_int8_t red_gif[] = {
  0x47,0x49,0x46,0x38, 0x39,0x61,0x0b,0x00, 0x04,0x00,0xf7,0x00,
  0x00,0xff,0x00,0x00,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
  0x00,0x21,0xf9,0x04,
  0x01,0x0a,0x00,0xff, 0x00,0x2c,0x00,0x00, 0x00,0x00,0x0b,0x00,
  0x04,0x00,0x07,0x08,
  0x0d,0x00,0x01,0x08, 0x1c,0x48,0xb0,0xa0, 0xc1,0x83,0x08,0x13,
  0x06,0x04,0x00,0x3b
};



/* ************************* */

typedef struct clientPw {
  char *user, *pw;
  struct clientPw *next;
} clientPw;

static clientPw *rootNode = NULL;


/* ************************* */

void readHTTPheader()
{
  char aChar, lastChar, preLastChar, lineStr[256];
  int rc, idxChar=0;

  pw[0] = '\0';
  preLastChar = '\r';
  lastChar = '\n';
  requestedURL[0] = '\0';

  for(;;)
    {
      rc = recv(newSock, &aChar, 1, 0);
      
      if(rc != 1)	
	{
	  idxChar=0;     
	  break; /* Empty line */
	}
      else
	{
	  /* printf("%c", aChar);  */
	  
	  if((aChar == '\n') && (lastChar == '\r') && (preLastChar == '\n'))
	    {
	      idxChar=0;
	      break;
	    }
	  else
	    {
	      if(aChar == '\n')
		{
		  lineStr[idxChar-1] = '\0';

		  /* printf("%s [%d]\n", lineStr, idxChar); */

		  if((idxChar >= 21)
		     && (strncmp(lineStr, "Authorization: Basic ", 21) == 0))
		    strcpy(pw, &lineStr[21]);
		  else if((idxChar >= 3)
			  && (strncmp(lineStr, "GET ", 4) == 0)) {
		    strcpy(requestedURL, &lineStr[4]);
		  }

		  idxChar=0;
		}
	      else
		{
		  if(idxChar < 256)
		    lineStr[idxChar++] = aChar;
		}

	      preLastChar = lastChar;
	      lastChar = aChar;
	    }			 
	}
    }
}

/* ************************* */

int decodeString(char *bufcoded, 
		 unsigned char *bufplain,
		 int outbufsize)
{
  /* single character decode */
#define DEC(c) pr2six[(int)c]
#define MAXVAL 63
  unsigned char pr2six[256];
  char six2pr[64] = {
    'A','B','C','D','E','F','G','H','I','J','K','L','M',
    'N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
    'a','b','c','d','e','f','g','h','i','j','k','l','m',
    'n','o','p','q','r','s','t','u','v','w','x','y','z',
    '0','1','2','3','4','5','6','7','8','9','+','/'
  };  
  /* static */ int first = 1;

  int nbytesdecoded, j;
  register char *bufin = bufcoded;
  register unsigned char *bufout = bufplain;
  register int nprbytes;

   /* If this is the first call, initialize the mapping table.
    * This code should work even on non-ASCII machines.
    */
  if(first) {
    first = 0;
    for(j=0; j<256; j++) pr2six[j] = MAXVAL+1;
    
    for(j=0; j<64; j++) pr2six[(int)six2pr[j]] = (unsigned char) j;
#if 0
    pr2six['A']= 0; pr2six['B']= 1; pr2six['C']= 2; pr2six['D']= 3; 
    pr2six['E']= 4; pr2six['F']= 5; pr2six['G']= 6; pr2six['H']= 7; 
    pr2six['I']= 8; pr2six['J']= 9; pr2six['K']=10; pr2six['L']=11; 
    pr2six['M']=12; pr2six['N']=13; pr2six['O']=14; pr2six['P']=15; 
    pr2six['Q']=16; pr2six['R']=17; pr2six['S']=18; pr2six['T']=19; 
    pr2six['U']=20; pr2six['V']=21; pr2six['W']=22; pr2six['X']=23; 
    pr2six['Y']=24; pr2six['Z']=25; pr2six['a']=26; pr2six['b']=27; 
    pr2six['c']=28; pr2six['d']=29; pr2six['e']=30; pr2six['f']=31; 
    pr2six['g']=32; pr2six['h']=33; pr2six['i']=34; pr2six['j']=35; 
    pr2six['k']=36; pr2six['l']=37; pr2six['m']=38; pr2six['n']=39; 
    pr2six['o']=40; pr2six['p']=41; pr2six['q']=42; pr2six['r']=43; 
    pr2six['s']=44; pr2six['t']=45; pr2six['u']=46; pr2six['v']=47; 
    pr2six['w']=48; pr2six['x']=49; pr2six['y']=50; pr2six['z']=51; 
    pr2six['0']=52; pr2six['1']=53; pr2six['2']=54; pr2six['3']=55; 
    pr2six['4']=56; pr2six['5']=57; pr2six['6']=58; pr2six['7']=59; 
    pr2six['8']=60; pr2six['9']=61; pr2six['+']=62; pr2six['/']=63;
#endif
  }

  /* Strip leading whitespace. */

  while(*bufcoded==' ' || *bufcoded == '\t') bufcoded++;

  /* Figure out how many characters are in the input buffer.
    * If this would decode into more bytes than would fit into
    * the output buffer, adjust the number of input bytes downwards.
    */
  bufin = bufcoded;
  while(pr2six[(int)*(bufin++)] <= MAXVAL)
    ;
   
  nprbytes = bufin - bufcoded - 1;
  nbytesdecoded = ((nprbytes+3)/4) * 3;
  if(nbytesdecoded > outbufsize) {
    nprbytes = (outbufsize*4)/3;
  }

  bufin = bufcoded;
   
  while (nprbytes > 0) {
    *(bufout++) = (unsigned char) (DEC(*bufin) << 2 | DEC(bufin[1]) >> 4);
    *(bufout++) = (unsigned char) (DEC(bufin[1]) << 4 | DEC(bufin[2]) >> 2);
    *(bufout++) = (unsigned char) (DEC(bufin[2]) << 6 | DEC(bufin[3]));
    bufin += 4;
    nprbytes -= 4;
  }
   
  if(nprbytes & 03) {
    if(pr2six[(int)bufin[-2]] > MAXVAL) {
      nbytesdecoded -= 2;
    } else {
      nbytesdecoded -= 1;
    }
  }

  return(nbytesdecoded);
}

/* ************************* */

void sendStringLen(char *theString, int len) {
  int bytesSent, rc, retries = 0;
  static char buffer[2*BUF_SIZE];

  if(len == 0)
    return; /* Nothing to send */
  else
    memcpy(buffer, theString, len);

  bytesSent = 0;

  while(len > 0)
    {
    RESEND:
      errno=0;
	  
      rc = send(newSock, &buffer[bytesSent], len, 0);

      /* printf("rc=%d\n", rc); */

      if((errno != 0) || (rc < 0))
	{
	  if((errno == EAGAIN /* Resource temporarily unavailable */) && (retries<3))
	    {
	      len -= rc;
	      bytesSent += rc;
	      retries++;
	      goto RESEND;
	    }
	  else if (errno == EPIPE /* Broken pipe: the  client has disconnected */)
	    {
#ifndef WIN32
		  close(newSock);
#else
		  closesocket(newSock);
#endif
	      return;
	    }
	  else if (errno == EBADF /* Bad file descriptor: a 
				     disconnected client is still sending */)
	    return;
	  else
	    return;
	}
      else
	{
	  len -= rc;
	  bytesSent += rc;
	}
    }
}

/* ************************* */

void sendString(char *theString) {
  sendStringLen(theString, strlen(theString));
}


/* ************************* */

void printHTTPheader() {
   char buf[BUF_SIZE];

   sendString("<HTML>\n<HEAD>\n<META HTTP-EQUIV=REFRESH CONTENT=");
   sprintf(buf, "%d", refreshRate); 
   sendString(buf);
   sendString(">\n</HEAD>\n<BODY BGCOLOR=#FFFFFF>\n");
}

/* ************************* */

void printHTTPtrailer() {
  char buf2[BUF_SIZE];
  sendString("\n</CENTER><hr><FONT FACE=Helvetica>");
  sprintf(buf2, "<H5>Generated by <A HREF=\"http://www-serra.unipi.it/~ntop/\">"
	  "ntop</A> v.%s %s [%s]"
#ifndef WIN32
	  " listening on %s"
#endif
	  "<br>\n", 
	  version, THREAD_MODE, osName, device); 
  sendString(buf2);    
  sendString("<address>&copy; 1998-99 by <A HREF=mailto:deri@unipi.it>L. Deri</A>"
	     "</H5></font></BODY></HTML>\n");
}

/* ************************* */

void returnHTTPaccessDenied() {
  sendString("HTTP/1.0 401 Unauthorized to access the document\n");	
  sendString("WWW-Authenticate: Basic realm=\"ntop HTTP server\"\n");
  sendString("Connection: close\n");
  sendString("Content-Type: text/html\n\n"); 
  sendString("<HTML>\n<TITLE>Error</TITLE>\n<BODY>\n"
	     "<H1>Error 401</H1>\nUnauthorized to access the document\n</BODY>\n</HTML>\n");
}

/* ************************* */

void returnHTTPPage(char* pageName) {
  char *questionMark = strchr(pageName, '?');
  int sortedColumn, printTrailer=1, idx;
  FILE *fd;
  char tmpStr[256], *sign;
  short revertOrder=0;

  if(questionMark == NULL)
    sortedColumn = 0;
  else {
    sortedColumn = abs(atoi(&questionMark[1]));

    if(questionMark[1] == '-')
      revertOrder=1;
  }

  sendString("HTTP/1.0 200 OK\n");
  sprintf(tmpStr, "Server: ntop/%s (%s)\n", version, osName);
  sendString(tmpStr);

  if(pageName[0] == '\0') strcpy(pageName, "index.html");

  /* Search in the local directory first... */
  for(idx=0; dirs[idx] != NULL; idx++) {    
    sprintf(tmpStr, "%s/html/%s", dirs[idx], pageName);    
    if((fd = fopen(tmpStr, "rb")) != NULL)
      break;
  }
  
  if(fd != NULL) {
    int len = strlen(pageName);
    
    if((len > 4) && (strcmp(&pageName[len-4], ".gif") == 0)) {
      sendString("Content-type: image/gif\n"); 
      fseek(fd, 0, SEEK_END);
      sprintf(tmpStr, "Content-length: %d\n\n", (len = ftell(fd)));
      fseek(fd, 0, SEEK_SET);
      sendString(tmpStr);			
    } else
      sendString("Content-type: text/html\n\n");
    
    for(;;)
      {
	len = fread(tmpStr, sizeof(char), 255, fd);
	if(len <= 0) break;
	sendStringLen(tmpStr, len);
      }
    
    fclose(fd);
    close(newSock);
    return;
  }

  /* There's no custom page, so let's generate one */

  /* Courtesy of Hans Werner Strube <strube@physik3.gwdg.de> */
  if(strcmp(pageName, "red.gif") == 0) {
    sendString("Content-type: image/gif\n\n");
    sendStringLen((char *)red_gif, sizeof(red_gif));
    return;
  } 

  sendString("Content-type: text/html\n\n");

  if(strcmp(pageName, "index.html") == 0) {
    sendString("<html>\n");
    sendString("<title>Welcome to ntop!</title>\n");
    sendString("</head>\n");
    sendString("<frameset cols=160,* FRAMESPACING=0 BORDER=0 FRAMEBORDER=0>\n");
    sendString("    <frame src=leftmenu.html name=Menu MARGINWIDTH=0 MARGINHEIGHT=0>\n");
    sendString("    <frame src=home.html name=area MARGINWIDTH=5 MARGINHEIGHT=0>\n");
    sendString("    <noframes>\n");
    sendString("    <body>\n\n");
    sendString("    </body>\n");
    sendString("    </noframes>\n");
    sendString("</frameset>\n");
    sendString("</html>\n");
  } else if(strcmp(pageName, "leftmenu.html") == 0) {
    sendString("<HTML>\n<BODY BGCOLOR=#663399 LINK=#CCCCFF VLINK=#FFFFFF>\n<center>\n<pre>\n\n</pre>\n\n");
    sendString("<FONT FACE=Helvetica SIZE=+2 COLOR=#FFFFFF>Welcome<br>to<br>\n");
    sendString("ntop!</FONT>\n<pre>\n</pre>\n");
    sendString("<p></center><p>\n<FONT FACE=Helvetica SIZE=-1 COLOR=#FFFFFF><b>\n<ol>\n");
    sendString("<li><a href=home.html target=area>What's ntop?</a></li>\n");
    sendString("<li>Data Rcvd<ul>");
    sendString("<li><a href="STR_SORT_DATA_RECEIVED_PROTOS" target=area "
	       "ALT=\"Data Received (all protocols)\">All Protoc.</a></li>\n");
    sendString("<li><a href="STR_SORT_DATA_RECEIVED_IP" target=area "
	       "ALT=\"IP Data Received\">IP</a></li>\n");
    sendString("<li><a href="STR_SORT_DATA_RECEIVED_THPT" target=area "
	       "ALT=\"Data Received Throughput\">Thpt</a></li></ul></li>\n");

    sendString("<li>Data Sent<ul>");
    sendString("<li><a href="STR_SORT_DATA_SENT_PROTOS" target=area "
	       "ALT=\"Data Sent (all protocols)\">All Protoc.</a></li>\n");
    sendString("<li><a href="STR_SORT_DATA_SENT_IP" target=area "
	       "ALT=\"IP Data Sent\">IP</a></li>\n");
    sendString("<li><a href="STR_SORT_DATA_SENT_THPT" target=area "
	       "ALT=\"Data Sent Throughput\">Thpt</a></li></ul></li>\n");
    sendString("<li><a href="STR_MULTICAST_STATS" target=area ALT=\"Multicast Stats\">"
	       "Multicast Stats</a></li>\n");
    sendString("<li><a href=trafficStats.html target=area ALT=\"Traffic Statistics\">"
	       "Traffic Stats</a></li>\n");
    sendString("<li><a href="STR_DOMAIN_STATS" target=area ALT=\"Domain Traffic Statistics\">"
	       "Domain Stats</a></li>\n");
    sendString("<li><a href=thptStats.html target=area ALT=\"Thtoughput Statistics\">"
	       "Thpt Stats</a></li>\n");
    sendString("<li><a href="HOSTS_INFO_HTML" target=area ALT=\"Hosts Information\">"
	       "Hosts Info</a></li>\n");
    sendString("<li><a href=IpR2L.html target=area ALT=\"Remote to Local IP Traffic\">"
	       "R->L IP Traffic</a></li>\n");
    sendString("<li><a href=IpL2R.html target=area ALT=\"Local to Remote IP Traffic\">"
	       "L->R IP Traffic</a></li>\n");
    sendString("<li><a href=IpL2L.html target=area ALT=\"Local IP Traffic\">"
	       "L<->L IP Traffic</a></li>\n");
    sendString("<li><a href=NetNetstat.html target=area ALT=\"Active TCP Sessions\">"
	       "Active TCP Sessions</a></li>\n");
    sendString("<li><a href=ipProtoDistrib.html target=area ALT=\"IP Protocol Distribution\">"
	       "IP Protocol Distribution</a></li>\n");
    sendString("<li><a href=ipProtoUsage.html target=area ALT=\"IP Protocol Subnet Usage\">"
	       "IP Protocol Usage</a></li>\n");
    sendString("<li><a href=ipTrafficMatrix.html target=area ALT=\"IP Traffic Matrix\">"
	       "IP Traffic Matrix</a></li>\n");
#ifdef HAVE_LSOF
    sendString("<li><a href="STR_LSOF_DATA" target=area "
	       "ALT=\"Local Processes Nw Usage\">Local Nw Usage</a></li>\n");
#endif /* HAVE_LSOF */


/* 
   Putting this here (and not on top of this function)
   helps because at least a partial respose
   has been send back to the user in the meantime 
*/
#ifdef MULTITHREADED
    accessMutex(&hostsHashMutex);
#endif

#ifndef WIN32
    if(flowsList != NULL)
      sendString("<li><a href=NetFlows.html target=area ALT=\"NetFlows\">"
		 "NetFlows List</a></li>\n");
#endif
    sendString("<li><a href=Credits.html target=area ALT=\"Credits\">Credits</a></li>\n");
    sendString("<li><a href=ntop.html target=area ALT=\"Man Page\">Man Page</a></li>\n");
    sendString("</ol>\n<center>\n<b>\n\n");
    sendString("<pre>\n</pre>&copy; 1998-99<br>by<br>"
	       "<A HREF=\"http://jake.unipi.it/~deri/\" target=\"area\">"
	       "Luca Deri</A></FONT><pre>\n");
    sendString("</pre>\n</b>\n</center>\n</body>\n</html>\n");    
    printTrailer=0;
  } else if(strcmp(pageName, "home.html") == 0) {
    sendString("<html>\n<body bgcolor=#FFFFFF><CENTER><FONT FACE=Helvetica><H1>Welcome to ntop!</H1></center><hr>");
    sendString("<b>ntop</b> shows the current network usage. It displays a list of hosts that are\n"); 
    sendString("currently using the network and reports information concerning the IP\n"); 
    sendString("(Internet Protocol) traffic generated by each host. The traffic is \n"); 
    sendString("sorted according to host and protocol. Protocols (user configurable) include:\n"); 
    sendString("<ul><li>TCP/UDP/ICMP<li>(R)ARP<li>IPX<li>DLC<li>Decnet<li>AppleTalk<li>Netbios<li>IP<ul><li>FTP<li>HTTP<li>DNS<li>Telnet<li>SMTP/POP/IMAP<li>SNMP<li>\n"); 
    sendString("NFS<li>X11</ul></UL>\n<p>\n"); 
    sendString("<b>ntop</b>'s author strongly believe in <A HREF=http://www.opensource.org/>\n");
    sendString("open source software</A> and encourage everyone to modify, improve\n ");
    sendString("and extend <b>ntop</b> in the interest of the whole Internet community according\n");
    sendString("to the enclosed licence (see COPYING).<p>Problems, bugs, questions, ");
    sendString("desirable enhancements, source code contributions, etc., should be sent to the ");
    sendString("<A HREF=mailto:ntop@unipi.it> mailing list</A>.\n</font>");
    sendString("</font></body></html>\n");
  } else if(strncmp(pageName, STR_SORT_DATA_RECEIVED_PROTOS, strlen(STR_SORT_DATA_RECEIVED_PROTOS)) == 0) {
    printHostsTraffic(0, 0, sortedColumn, revertOrder);
  } else if(strncmp(pageName, STR_SORT_DATA_RECEIVED_IP, strlen(STR_SORT_DATA_RECEIVED_IP)) == 0) {
    printHostsTraffic(0, 1, sortedColumn, revertOrder);
  } else if(strncmp(pageName, STR_SORT_DATA_THPT_STATS, strlen(STR_SORT_DATA_THPT_STATS)) == 0) {
    printThptStats(sortedColumn);
  } else if(strncmp(pageName, STR_SORT_DATA_RECEIVED_THPT, strlen(STR_SORT_DATA_RECEIVED_THPT)) == 0) {
    printHostsTraffic(0, 2, sortedColumn, revertOrder);
  } else if(strncmp(pageName, STR_SORT_DATA_SENT_PROTOS, strlen(STR_SORT_DATA_SENT_PROTOS)) == 0) {
    printHostsTraffic(1, 0, sortedColumn, revertOrder);
  } else if(strncmp(pageName, STR_SORT_DATA_SENT_IP, strlen(STR_SORT_DATA_SENT_IP)) == 0) {
    printHostsTraffic(1, 1, sortedColumn, revertOrder);
  } else if(strncmp(pageName, STR_SORT_DATA_SENT_THPT, strlen(STR_SORT_DATA_SENT_THPT)) == 0) {
    printHostsTraffic(1, 2, sortedColumn, revertOrder);
  } else if(strncmp(pageName, HOSTS_INFO_HTML, strlen(HOSTS_INFO_HTML)) == 0) {
    printHostsInfo(sortedColumn, revertOrder);
  }
#ifdef HAVE_LSOF
  else if(strncmp(pageName, PROCESS_INFO_HTML, strlen(PROCESS_INFO_HTML)) == 0) {
    printProcessInfo(sortedColumn /* process PID */);
  } else if(strncmp(pageName, STR_LSOF_DATA, strlen(STR_LSOF_DATA)) == 0) {
    printLsofData(sortedColumn);
  } 
#endif /* HAVE_LSOF */
#ifndef WIN32
  else if(strcmp(pageName, "NetFlows.html") == 0) {
    listNetFlows();
  } 
#endif
  else if(strncmp(pageName, IP_R_2_L_HTML, strlen(IP_R_2_L_HTML)) == 0) {
    printHTTPheader();
    sendString("<CENTER><p><H1><FONT FACE=Helvetica>Remote to Local IP Traffic</FONT></H1><p>\n");
    printIpAccounting(REMOTE_TO_LOCAL_ACCOUNTING, sortedColumn, revertOrder);
    sendString("</CENTER></BODY></HTML>\n");
  } else if(strncmp(pageName, IP_L_2_R_HTML, strlen(IP_L_2_R_HTML)) == 0) {
    printHTTPheader();
    sendString("<CENTER><p><H1><FONT FACE=Helvetica>Local to Remote IP Traffic</FONT></H1><p>\n");
    printIpAccounting(LOCAL_TO_REMOTE_ACCOUNTING, sortedColumn, revertOrder);
    sendString("</CENTER></BODY></HTML>\n");
 } else if(strncmp(pageName, IP_L_2_L_HTML, strlen(IP_L_2_L_HTML)) == 0) {
    printHTTPheader();
    sendString("<CENTER><p><H1><FONT FACE=Helvetica>Local IP Traffic</FONT></H1><p>\n");
    printIpAccounting(LOCAL_TO_LOCAL_ACCOUNTING, sortedColumn, revertOrder);
    sendString("</CENTER></BODY></HTML>\n");
  } else if(strcmp(pageName, "NetNetstat.html") == 0) {
    printHTTPheader();
    sendString("<CENTER><p><H1><FONT FACE=Helvetica>Active TCP Sessions</FONT></H1><p>\n");
    printActiveTCPSessions();
    sendString("</CENTER></BODY></HTML>\n");
  } else if(strncmp(pageName, STR_MULTICAST_STATS, strlen(STR_MULTICAST_STATS)) == 0) {
    printMulticastStats(sortedColumn, revertOrder);
  } else if(strncmp(pageName, STR_DOMAIN_STATS, strlen(STR_DOMAIN_STATS)) == 0) {
    printDomainStats(abs(sortedColumn), revertOrder);
  } else if(strcmp(pageName, "trafficStats.html") == 0) {
    printHTTPheader();
    printHostsTraffic(2, 0, 0, revertOrder);
    printProtoTraffic();
    sendString("<p>\n");
    printIpProtocolDistribution(LONG_FORMAT, revertOrder);
    sendString("<p></BODY></HTML>\n");
  } else if(strcmp(pageName, "ipProtoDistrib.html") == 0) {
    printHTTPheader();
    printIpProtocolDistribution(SHORT_FORMAT, revertOrder);
    sendString("</BODY></HTML>\n");
  } else if(strcmp(pageName, "ipTrafficMatrix.html") == 0) {
    printHTTPheader();
    sendString("<CENTER><p><H1><FONT FACE=Helvetica>IP Subnet Traffic Matrix</FONT></H1><p>\n");
    printIpTrafficMatrix();
    sendString("</BODY></HTML>\n");
  } else if(strcmp(pageName, "ipProtoUsage.html") == 0) {
    printHTTPheader();
    sendString("<CENTER><p><H1><FONT FACE=Helvetica>IP Protocol Subnet Usage</FONT></H1><p>\n");
    printIpProtocolUsage();
    sendString("</BODY></HTML>\n");
   } else if(strcmp(pageName, "Credits.html") == 0) {
    sendString("<HTML>\n<BODY BGCOLOR=#FFFFFF>\n<FONT FACE=Helvetica>\n");
	sendString("<H1><center>Credits</H1></center><p><hr><br><b>ntop</b> has been created by\n");
	sendString("<A HREF=\"http://jake.unipi.it/~deri/\">Luca Deri</A> while studying how to model\n");
	sendString("network traffic. He was unsatisfied of the many network traffic analysis tools\n");
	sendString("he had access to, and decided to write a new application able to report network\n");
	sendString("traffic information in a way similar to the popular Unix top command. At that \n");
	sendString("point in time (it was June 1998) <b>ntop</b> was born.<p>The current release is very\n");
	sendString("different from the initial one for several reasons. In particular it: <ul>\n");
	sendString("<li>is much more sofisticated <li>has both a command line and a web interface\n");
	sendString("<li>is capable of handling both IP and non IP protocols </ul> <p> Although it\n");
	sendString("might not seem so, <b>ntop</b> has definitively more than an author.\n");
	sendString("<A HREF=\"mailto:stefano@unipi.it\">Stefano Suin</A> has contributed with ");
	sendString("some code fragments to the verion 1.0 of <b>ntop</b>\n");
	sendString("crew. In addition, many other people downloaded this program, tested it,\n");
	sendString("joined the <A HREF=http://mailserver.unipi.it/lists/ntop/archive/>ntop mailing list</A>,\n");
	sendString("reported problems, changed it and improved significantly. This is because\n");
	sendString("they have realised that <b>ntop</b> doesn't belong uniquely to its author, but\n");
	sendString("to the whole Internet community. Their names are throught "
		   "the whole <b>ntop</b> code.<p>");
	sendString("The author would like to thank all these people who contributed to <b>ntop</b> and\n");
	sendString("turned it into a first class network monitoring tool. Many thanks guys!<p>\n");
	sendString("</FONT><p>\n");
  } else if(strlen(pageName) > 5) {
    int i;
    char hostName[32];

    pageName[strlen(pageName)-5] = '\0';

    /* Patch for ethernet addresses and MS Explorer */
    for(i=0; pageName[i] != '\0'; i++) 
      if(pageName[i] == '_')
	pageName[i] = ':';

    strcpy(hostName, pageName);
    printHTTPheader();
    printAllSessionsHTML(hostName);
    sendString("</CENTER>\n");
  } else {
    printHTTPheader();
    sendString("<HTML>\n<TITLE>???</TITLE>\n<BODY>\n<H1>Error</H1>\nUnknown page\n"); 
  }

  if(printTrailer) printHTTPtrailer();

#ifdef MULTITHREADED
  releaseMutex(&hostsHashMutex);
#endif      
}

/* ************************* */

/* similar to Java.String.trim() */
void trimString(char* str)
{
  int len = strlen(str), i, idx;
  char out[512];

  for(i=0, idx=0; i<len; i++)
    {
      switch(str[i])
	{
	case ' ':
	case '\t':
	  if((idx > 0) 
	     && (out[idx-1] != ' ') 
	     && (out[idx-1] != '\t'))
	  out[idx++] = str[i];
	  break;
	default:
	  out[idx++] = str[i];
	  break;
	}
    }

  out[idx] = '\0';
  strcpy(str, out);
}

/* ************************* */

void readConfigurationFile()
{
  FILE *fd;
  char tmpStr[512], name[64], pw[64], *home;
  int line=0, idx;
  clientPw *clientInfo;

  pw[0] = '\0';

#ifndef WIN32 
  /* Fix courtesy of "Richard L. Hamilton" <rlhamil@mindwarp.smart.net> */
  sprintf(tmpStr, "%s/.ntop", (home=getenv("HOME"))!=NULL?home:"");

  if((fd = fopen(tmpStr, "r")) == NULL)
    for(idx=0; dirs[idx] != NULL; idx++) {    
      sprintf(tmpStr, "%s/.ntop", dirs[idx]);    
#ifdef DEBUG
      printf("Trying '%s'...\n", dirs[idx], tmpStr);
#endif
      if((fd = fopen(tmpStr, "rb")) != NULL) {
	printf("Using '%s'\n", tmpStr);
	break;
      }
    }

#else
  fd = fopen(".ntop", "r");
#endif

  if(fd == NULL)
    {
      printf("Warning: unable to read file '.ntop'. No security will be used!\n");
      return;
    }

  while(fgets(tmpStr, 512, fd))
    {
      int theStrLen = strlen(tmpStr);
      line++;

      /* Courtesy of Leon Verrall <leon@reading.sgi.com> */
      if(tmpStr[theStrLen-1] == '\n')
	tmpStr[theStrLen-1] = '\0'; /* Remove final '\n' */
      
      switch(tmpStr[0])
	{
	case '\n':
	case '\0':
	case '#':
	  break;

	default:
	  trimString(tmpStr); /* Remove uneeded spaces/tabs */
	  /* printf("%s\n", tmpStr); */
	  sscanf(tmpStr, "%s\t%s", name, pw);
	}

      if((name[0] != '\0')&& (pw[0] != '\0')) {
	clientInfo = (clientPw*)malloc(sizeof(clientPw));
	clientInfo->user = strdup(name);
	clientInfo->pw   = strdup(pw);
	clientInfo->next = rootNode;
	rootNode = clientInfo;
	
	/* printf("Name=%s\nPw=%s\n", name, pw); */
      }
    }
  
  fclose(fd);
}

/* ************************* */

int checkHTTPpassword() {
  char outBuffer[64], *user;
  int i;
  clientPw *scanner = rootNode;

  if(scanner == NULL)
    return 1; /* Access granted - security is disabled */

  i = decodeString(pw, (unsigned char*)outBuffer, 64);

  if(i == 0)
    {
      user = "", pw[0] = '\0';
      outBuffer[0] = '\0';
    }
  else
    {
      outBuffer[i] = '\0';

      for(i=0; i<64; i++)
	if(outBuffer[i] == ':')
	  {
	    outBuffer[i] = '\0';
	    user = outBuffer;
	    break;
	  }

      strcpy(pw, &outBuffer[i+1]);
    }

  /* printf("%s-%s\n", user, pw); */

  while(scanner != NULL) {
    if((strcmp(scanner->user, user) == 0)
       && (strcmp(scanner->pw, pw) == 0))
      return(1);
    else
      scanner = scanner->next;
  }
  
  return 0;
}

/* ************************* */

void handleHTTPrequest() {
  readHTTPheader();
  
  if(checkHTTPpassword() != 1) {
    returnHTTPaccessDenied();
    return;
  }

  /* fprintf(stdout, "URL = '%s'\n", requestedURL);  */

  actTime = time(NULL); /* Don't forget this */

  if((requestedURL[0] == '\0')
     || (strncmp(requestedURL, "/", 1) == 0)
     || (strncmp(requestedURL, "/index.html", strlen("/index.html")) == 0)
     || (strncmp(requestedURL, "/leftmenu.html", strlen("/leftmenu.html")) == 0)
     || (strncmp(requestedURL, "/home.html", strlen("/home.html")) == 0)) {
    requestedURL[strlen(requestedURL)-9] = '\0';
    returnHTTPPage(&requestedURL[1]);
  } else {
    char buf[64];

    sendString("HTTP/1.0 200 OK\n");
    sprintf(buf, "Server: ntop/%s (%s)\n", version, osName);
    sendString(buf);
    sendString("Content-Type: text/html\n\n"); 
    sendString("<HTML>\n<TITLE>???</TITLE>\n<BODY>\n"
	       "<H1>Error</H1>\nUnkown page\n</BODY>\n</HTML>\n");
  }
}

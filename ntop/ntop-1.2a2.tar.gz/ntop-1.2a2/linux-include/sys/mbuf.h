/* @(#) $Header: mbuf.h,v 1.1 96/12/31 16:40:40 leres Exp $ (LBL) */

#ifndef MLEN
#define MLEN 128			/* needed for slcompress.h */
#endif

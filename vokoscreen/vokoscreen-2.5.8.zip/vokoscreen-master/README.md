**GUI**  
For transparent effects in the area, countdown, and showclick, a switched-on compositer is needed, otherwise the surfaces appear in black.

**Translat**  
Please translate only at Transifex, it is very easy.  
https://www.transifex.com/vkohaupt/vokoscreen/

**Homepage**  
http://linuxecke.volkoh.de/vokoscreen/vokoscreen.html

**Second Homepage**  
http://www.kohaupt-online.de/hp/

**Description and Screenshots**  
vokoscreen is an easy to use screencast creator to record educational videos, live recordings of browser, installation, videoconferences, etc.

![Picture](http://linuxecke.volkoh.de/vokoscreen/vokoscreen-picture-screen.png)
![Picture](http://linuxecke.volkoh.de/vokoscreen/vokoscreen-picture-audio.png)
![Picture](http://linuxecke.volkoh.de/vokoscreen/vokoscreen-picture-codec.png)
![Picture](http://linuxecke.volkoh.de/vokoscreen/vokoscreen-picture-miscellaneous.png)
![Picture](http://linuxecke.volkoh.de/vokoscreen/vokoscreen-picture-webcam.png)
![Picture](http://linuxecke.volkoh.de/vokoscreen/vokoscreen-picture-about.png)
![Picture](http://linuxecke.volkoh.de/vokoscreen/vokoscreen-picture-webcambusy.png)
![Picture](http://linuxecke.volkoh.de/vokoscreen/vokoscreen-picture-area.png)
![Picture](http://linuxecke.volkoh.de/vokoscreen/vokoscreen-picture-credits.png)

Qt5 Support 

qxtglobalshortcut is from https://github.com/smarttowel/qxtglobalshortcut

qxtwindowsystem is from ????

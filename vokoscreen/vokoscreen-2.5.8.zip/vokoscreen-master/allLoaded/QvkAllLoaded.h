
// Achtung
// Bei weiteren Globalen Variablen muß diese noch zusätzlich in der main deklariert werden
// anschließend in QvkDBus::isVokoscreenLoaded mit einbauen
extern bool cameraLoaded;


#ifndef QvkLogController_H 
#define QvkLogController_H

#include "ui_formMainWindow.h"

#include <QObject>

class QvkLogController : public QObject
{
    Q_OBJECT

public:
  QvkLogController( Ui_formMainWindow *ui_mainwindow);
  virtual ~QvkLogController();
  

public slots:

  
signals:

  
private slots:

  
private:


protected:
  
  
};

#endif
